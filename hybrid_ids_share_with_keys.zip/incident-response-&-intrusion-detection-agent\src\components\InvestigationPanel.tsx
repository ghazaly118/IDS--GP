import React, { useState } from "react";
import { 
  FileText, 
  Map, 
  ShieldCheck, 
  AlertOctagon, 
  Activity, 
  User, 
  Tag, 
  ExternalLink,
  ChevronRight,
  ClipboardList,
  CheckCircle,
  HelpCircle
} from "lucide-react";
import { Incident } from "../types";

interface InvestigationPanelProps {
  activeIncident: Incident | null;
  onOpenTicket: (title: string, priority: string) => void;
  isOpeningTicket: boolean;
}

export default function InvestigationPanel({ activeIncident, onOpenTicket, isOpeningTicket }: InvestigationPanelProps) {
  const [activeTab, setActiveTab] = useState<"findings" | "report">("findings");
  const [ticketPriority, setTicketPriority] = useState<string>("High");
  const [ticketCreated, setTicketCreated] = useState<boolean>(false);

  const handleCreateTicket = () => {
    if (!activeIncident) return;
    const title = `Incident ${activeIncident.id} escalation - ${activeIncident.attack_type} on ${activeIncident.target_host}`;
    onOpenTicket(title, ticketPriority);
    setTicketCreated(true);
    setTimeout(() => setTicketCreated(false), 4000);
  };

  const getSeverityColor = (sev: string) => {
    switch (sev?.toLowerCase()) {
      case "critical": return "text-red-500 bg-red-500/10 border-red-500/30";
      case "high": return "text-orange-500 bg-orange-500/10 border-orange-500/30";
      case "medium": return "text-yellow-500 bg-yellow-500/10 border-yellow-500/30";
      default: return "text-emerald-500 bg-emerald-500/10 border-emerald-500/30";
    }
  };

  if (!activeIncident) {
    return (
      <div className="flex flex-col items-center justify-center h-full bg-slate-900 border border-slate-800 rounded-xl p-8 text-center text-slate-400 gap-4" id="investigation-placeholder">
        <div className="w-16 h-16 rounded-full bg-slate-950 flex items-center justify-center border border-slate-800 text-indigo-400">
          <Activity className="w-8 h-8 animate-pulse" />
        </div>
        <div>
          <h3 className="text-md font-semibold text-white tracking-tight">SecOps Forensics Engine Idle</h3>
          <p className="text-xs text-slate-400 max-w-xs mx-auto mt-1">
            Uplink a network flow and click "Run Autonomous AI Incident Responder" to begin automated investigation.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-4 h-full bg-slate-900 border border-slate-800 rounded-xl p-5 shadow-2xl overflow-y-auto" id="investigation-details-panel">
      {/* Header and Tabs */}
      <div className="flex justify-between items-start border-b border-slate-800 pb-3" id="investigation-header">
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="text-[11px] font-bold bg-slate-950 text-indigo-300 px-2 py-0.5 rounded font-mono border border-slate-800">
              {activeIncident.id}
            </span>
            <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded uppercase border ${getSeverityColor(activeIncident.severity)}`}>
              {activeIncident.severity}
            </span>
          </div>
          <h2 className="text-sm font-bold text-white tracking-tight mt-1 truncate max-w-[280px]">
            {activeIncident.attack_type}
          </h2>
        </div>

        {/* Tab Controls */}
        <div className="flex bg-slate-950 p-1 rounded-lg border border-slate-800/80">
          <button
            id="tab-findings-btn"
            onClick={() => setActiveTab("findings")}
            className={`text-[10px] px-2.5 py-1 rounded-md font-medium transition-all ${
              activeTab === "findings" ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white"
            }`}
          >
            AI Findings
          </button>
          <button
            id="tab-report-btn"
            onClick={() => setActiveTab("report")}
            className={`text-[10px] px-2.5 py-1 rounded-md font-medium transition-all ${
              activeTab === "report" ? "bg-indigo-600 text-white" : "text-slate-400 hover:text-white"
            }`}
          >
            Forensic Report
          </button>
        </div>
      </div>

      {activeTab === "findings" ? (
        <div className="flex flex-col gap-4" id="tab-findings-content">
          
          {/* Severity Scorer & CVSS v3 */}
          <div className="grid grid-cols-3 gap-3 bg-slate-950 border border-slate-800/80 rounded-xl p-3.5" id="severity-scorer-dashboard">
            <div className="flex flex-col items-center justify-center border-r border-slate-800 pb-1">
              <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider">CVSS v3.1</span>
              <span className={`text-2xl font-black mt-1 ${activeIncident.cvss >= 9 ? 'text-red-500' : activeIncident.cvss >= 7 ? 'text-orange-500' : 'text-yellow-500'}`}>
                {activeIncident.cvss.toFixed(1)}
              </span>
            </div>

            <div className="col-span-2 flex flex-col justify-center pl-2">
              <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider">Attack Priority Score</span>
              <div className="flex items-center gap-1.5 mt-1">
                <AlertOctagon className="w-3.5 h-3.5 text-orange-400" />
                <span className="text-[11px] font-semibold text-slate-200">
                  {activeIncident.severity === "Critical" ? "Immediate Containment Required" : "Escalated Core Investigation"}
                </span>
              </div>
              <p className="text-[9px] text-slate-500 mt-1 truncate font-mono bg-slate-900 px-1 py-0.5 rounded select-all border border-slate-800">
                {activeIncident.cvss_vector || "CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:C/C:H/I:H/A:H"}
              </p>
            </div>
          </div>

          {/* MITRE ATT&CK Mapping */}
          <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3.5 flex flex-col gap-2" id="mitre-attack-panel">
            <div className="flex items-center gap-1.5 border-b border-slate-800/50 pb-1.5">
              <Map className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-semibold text-slate-300">MITRE ATT&CK Framework Mapping</span>
            </div>

            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center bg-slate-900 border border-slate-800/60 p-2 rounded-lg">
                <div className="flex flex-col">
                  <span className="text-[8px] font-bold text-slate-500 uppercase">Tactic</span>
                  <span className="text-[11px] font-medium text-slate-300">{activeIncident.mitre.tactic}</span>
                </div>
                <ChevronRight className="w-3.5 h-3.5 text-slate-600" />
                <div className="flex flex-col text-right">
                  <span className="text-[8px] font-bold text-slate-500 uppercase">Technique ID</span>
                  <span className="text-[11px] font-mono text-indigo-400 font-bold">{activeIncident.mitre.id}</span>
                </div>
              </div>

              <div className="flex flex-col gap-1 px-1">
                <span className="text-[9px] font-bold text-slate-500 uppercase">Technique Descriptor</span>
                <span className="text-xs font-semibold text-slate-200">{activeIncident.mitre.name}</span>
                <p className="text-[10px] text-slate-400 leading-relaxed mt-0.5">
                  The attacker used identified interfaces to interact directly with core server bindings, triggering automated state payloads.
                </p>
              </div>
            </div>
          </div>

          {/* LLM Investigator Analysis Summary */}
          <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3.5 flex flex-col gap-2" id="forensic-notes-panel">
            <div className="flex items-center gap-1.5 border-b border-slate-800/50 pb-1.5">
              <ClipboardList className="w-4 h-4 text-indigo-400" />
              <span className="text-xs font-semibold text-slate-300">IR Investigator Notes</span>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed font-sans bg-slate-900/60 p-2.5 rounded-lg border border-slate-800/40">
              {activeIncident.investigation_summary}
            </p>
          </div>

          {/* Target victim info list */}
          <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3.5 flex flex-col gap-2" id="victim-intel-panel">
            <span className="text-[10px] font-bold text-slate-500 uppercase">Target Victim Intelligence</span>
            <div className="grid grid-cols-2 gap-2 text-[11px] font-mono">
              <div className="flex justify-between bg-slate-900/40 border border-slate-800/50 p-1.5 rounded">
                <span className="text-slate-500">Asset:</span>
                <span className="text-slate-300">{activeIncident.target_host}</span>
              </div>
              <div className="flex justify-between bg-slate-900/40 border border-slate-800/50 p-1.5 rounded">
                <span className="text-slate-500">Victim IP:</span>
                <span className="text-indigo-400">{activeIncident.target_ip}</span>
              </div>
              <div className="flex justify-between bg-slate-900/40 border border-slate-800/50 p-1.5 rounded col-span-2">
                <span className="text-slate-500">Attacker Root:</span>
                <span className="text-red-400">{activeIncident.source_ip}</span>
              </div>
            </div>
          </div>

          {/* Ticket Workflow Section */}
          <div className="bg-slate-950 border border-slate-800/80 rounded-xl p-3.5 flex flex-col gap-2.5" id="incident-ticketing-workflow">
            <div className="flex justify-between items-center border-b border-slate-800/50 pb-1.5">
              <span className="text-xs font-semibold text-slate-300">Escalate IT Service Ticket</span>
              <span className="text-[10px] bg-indigo-500/10 text-indigo-400 px-1.5 py-0.5 rounded font-mono font-bold">Jira/ServiceNow sync</span>
            </div>

            <div className="flex items-center gap-3">
              <div className="flex-1 flex flex-col gap-1">
                <label className="text-[8px] font-bold text-slate-500 uppercase">Escalation Priority</label>
                <select
                  id="ticket-priority-select"
                  value={ticketPriority}
                  onChange={(e) => setTicketPriority(e.target.value)}
                  className="bg-slate-900 border border-slate-800 text-xs text-slate-300 px-2 py-1.5 rounded-lg focus:outline-none"
                >
                  <option value="Low">Low Priority</option>
                  <option value="Medium">Medium Priority</option>
                  <option value="High">High Priority</option>
                  <option value="Critical">Critical P0 Priority</option>
                </select>
              </div>

              <button
                id="create-escalation-ticket-btn"
                onClick={handleCreateTicket}
                disabled={isOpeningTicket || ticketCreated}
                className="bg-slate-800 hover:bg-indigo-600 disabled:opacity-50 text-white font-medium text-xs px-4 py-2.5 rounded-lg border border-slate-700/60 flex items-center justify-center gap-2 transition-all self-end"
              >
                {ticketCreated ? (
                  <>
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-400" />
                    <span>Ticket Logged!</span>
                  </>
                ) : (
                  <>
                    <ClipboardList className="w-3.5 h-3.5" />
                    <span>Generate Ticket</span>
                  </>
                )}
              </button>
            </div>
          </div>

        </div>
      ) : (
        <div className="flex flex-col gap-3" id="tab-report-content">
          <div className="flex justify-between items-center bg-slate-950 border border-slate-800 p-2.5 rounded-lg text-xs">
            <span className="text-slate-400 font-medium flex items-center gap-1.5">
              <FileText className="w-4 h-4 text-indigo-400" /> Markdown Forensic Summary
            </span>
            <span className="text-[10px] text-slate-500 font-mono">Format: RFC-7468 compliant</span>
          </div>

          <div 
            id="markdown-viewer"
            className="w-full h-[380px] bg-slate-950 border border-slate-800 rounded-lg p-4 font-mono text-[11px] text-slate-300 overflow-y-auto leading-relaxed select-text"
          >
            {activeIncident.markdown_report ? (
              <pre className="whitespace-pre-wrap font-sans text-xs prose prose-invert">
                {activeIncident.markdown_report}
              </pre>
            ) : (
              <p className="text-slate-500 italic text-center py-10">Forensic Investigation Report is generating or empty.</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
